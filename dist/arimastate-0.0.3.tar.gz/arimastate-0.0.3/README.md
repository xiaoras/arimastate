# arimastate
python module for state space formulation of arima models
